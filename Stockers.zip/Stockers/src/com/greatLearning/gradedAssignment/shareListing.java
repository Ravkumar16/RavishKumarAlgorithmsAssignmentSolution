package com.greatLearning.gradedAssignment;

public class shareListing {
	private double sharePrice;
	private boolean sharePriceTrend;

	public boolean isSharePriceTrend() {
		return sharePriceTrend;
	}

	public void setSharePriceTrend(boolean sharePriceTrend) {
		this.sharePriceTrend = sharePriceTrend;
	}

	public double getSharePrice() {
		return sharePrice;
	}

	public void setSharePrice(double sharePrice) {
		this.sharePrice = sharePrice;
	}

}
