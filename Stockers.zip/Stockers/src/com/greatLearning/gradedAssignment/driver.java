package com.greatLearning.gradedAssignment;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class driver {
	static int countOfCompany;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the no of companies");
		
		@SuppressWarnings("resource")
		Scanner myObj = new Scanner(System.in);
		
		countOfCompany = myObj.nextInt();
		shareListing comp[] = new shareListing[countOfCompany];
				
		for (int i=0; i<countOfCompany; i++){
			System.out.println("Enter current stock price of the company " + i);	
			comp[i].setSharePrice(myObj.nextDouble());
			System.out.println("Whether company's stock price rose today compare to yesterday in true or false only?");
			
			comp[i].setSharePriceTrend(myObj.nextBoolean());
			
		}
	
	    Comparator<shareListing> sharePriceCompare = Comparator.comparing(shareListing::getSharePrice);
	    Arrays.sort(comp, sharePriceCompare);
	    
	    System.out.println("Enter the operation that you want to perform");
	    System.out.println("1. Display the companies stock prices in ascending order");
	    System.out.println(" 2. Display the companies stock prices in descending order");
	    System.out.println("3. Display the total no of companies for which stock prices rose today");
	    System.out.println("4. Display the total no of companies for which stock prices declined today");
	    System.out.println("5. Search a specific stock price");
	    System.out.println(" 6. press 0 to exit ");
   
	    int operation = myObj.nextInt();
	    
	    driver dr = new driver();
	    switch (operation){
	    case 1:
	    	dr.printStockPriceAscenting(comp);
	    	break;
	    case 2:
	    	dr.printStockPriceDscenting(comp);
	    	break;
	    case 3:
	    	dr.printStockPriceRoseToday(comp);
	    	 break;
	    case 4:
	    	dr.printStockPriceFallToday(comp);
	    	break;
	    case 5:
	    	dr.printStockPriceSearch(comp);
	    	break;
	    case 0:
	    	System.out.println("Exited successfully");
	    	break;
	    default:
	    	System.out.println("invalid choice");
	    	break;
	    	
	    }
	    
	}
	
	 public void printStockPriceAscenting(shareListing e[]){
         System.out.println("Stock prices in ascending order are :");
           for (int j=0; j<e.length; j++){
          	 
          	 System.out.println(e[j].getSharePrice());
            	 
           }
        
         
      	}
         
public void printStockPriceDscenting(shareListing e[]){
         System.out.println("Stock prices in dscending order are :");
           for (int j=e.length-1; j>-1; j--){
          	 
          	 System.out.println(e[j].getSharePrice());
            	 
           }
        
         
      	}

public void printStockPriceRoseToday(shareListing e[]){

    int count =0;
      for (int l=0 ; l<e.length; l++){
   	   
   	  if (e[l].isSharePriceTrend()) {        	 
   		  count ++;
       	 
   	  }
   
    
 	}
         
      System.out.println("Total no of companies whose stock price rose today ::" + count );     
}
public void printStockPriceFallToday(shareListing e[]){
	 
    int count1 =0;
      for (int l=0 ; l<e.length; l++){
   	   
   	  if (!e[l].isSharePriceTrend()) {        	 
   		  count1 ++;
       	 
   	  }
   
    
 	}
         
      System.out.println("Total no of companies whose stock price fall today ::" + count1 );     
}	


public void printStockPriceSearch(shareListing e[]){
	  double search;
	  System.out.println("enter the key value" ); 
	  
	  @SuppressWarnings("resource")
	Scanner myObj = new Scanner(System.in);
	  search = myObj.nextDouble();

      for (int l=0 ; l<e.length; l++){
   	   
   	  if (e[l].getSharePrice()==search) {        	 
   		System.out.println("Stock of value " +search+" is present" ); 
       	 
   	  }
   
    
 	}
         
          
}	
	
}
