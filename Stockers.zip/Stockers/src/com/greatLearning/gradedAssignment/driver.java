package com.greatLearning.gradedAssignment;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Scanner;

public class driver {
	static int countOfCompany;
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter the no of companies");
		
		@SuppressWarnings("resource")
		Scanner myObj = new Scanner(System.in);
		
		countOfCompany = myObj.nextInt();
		shareListing comp[] = new shareListing[countOfCompany];
				
		for (int i=0; i<countOfCompany; i++){
			System.out.println("Enter current stock price of the company " + i);	
			comp[i].setSharePrice(myObj.nextDouble());
			System.out.println("Whether company's stock price rose today compare to yesterday in true or false only?");
			
			comp[i].setSharePriceTrend(myObj.nextBoolean());
			
		}
		
	    Comparator<shareListing> sharePriceCompare
        = Comparator.comparing(shareListing::getSharePrice);
     Arrays.sort(comp, sharePriceCompare);
     
     for (int j=0; j<countOfCompany; j++){
    	 
     }

	}

}
